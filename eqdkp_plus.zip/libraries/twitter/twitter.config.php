<?php
	if ( !defined('EQDKP_INC') ){
		header('HTTP/1.0 404 Not Found');exit;
	}

	define('TWITTER_CONSUMER_KEY', 'ItNGfcOeHbHJMcpEh3PbFw');
	define('TWITTER_CONSUMER_SECRET', 'OUttB2gryOgVd5iYvtMb2pCRefaQjeOfYkffsZrM');
	define('TWITTER_OAUTH_TOKEN', '1141969987-tqPcddQqnuh07ww1sOCM0a0x2FJPU0FaaHVkdVr');
	define('TWITTER_OAUTH_SECRET', 'kpT2MHMUFlFkYrdcD1R4EmeWXxQDqHmQsgnDzREBPE');
?>